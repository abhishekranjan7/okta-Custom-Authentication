import React from 'react';

const Home = () => <h3>Protected</h3>;
export default Home;